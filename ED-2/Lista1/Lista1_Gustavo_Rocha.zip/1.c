#include <stdio.h>
//Aluno: Gustavo Souza Rocha
//Matrícula: 20232003300021
int main() {
    int a, b, x;
    scanf("%d %d", &a, &b);
    x = a + b;
    printf("X = %d\n", x);
}