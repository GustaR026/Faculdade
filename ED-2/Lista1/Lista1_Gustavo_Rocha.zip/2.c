#include <stdio.h>
// Aluno: Gustavo Souza Rocha
// Matrícula: 20232003300021
int main() {
    float a, b, media;
    scanf("%f %f", &a, &b);
    media = (a * 3.5 + b * 7.5) / 11;
    printf("MEDIA = %.5f\n", media);
}